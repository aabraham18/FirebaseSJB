package com.acharte.firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    //Declaracion de VARIABLES

    EditText txt_correo, txt_password;
    Button btn_iniciar_sesion;

    //Componentes Firebase
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAutchListener;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Instanciamos el componete de Firebase Authentication
        mAuth = FirebaseAuth.getInstance();


        //Casteo de varibles
        txt_correo = findViewById(R.id.txt_correo);
        txt_password = findViewById(R.id.txt_password);
        btn_iniciar_sesion = findViewById(R.id.btn_iniciar_sesion);


        //Eventos(focus, hover, click)
        btn_iniciar_sesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               //IniciarSesion();
                Registro();
            }
        });
    }

    private void Registro() {
        String correo = txt_correo.getText().toString().trim();
        String password = txt_password.getText().toString().trim();

        //Validamos que el valor correo no este vacio
        if (TextUtils.isEmpty(correo)) {
            Toast.makeText(this, "El campo correo electronico esta vacio", Toast.LENGTH_SHORT).show();
            return;
        }

        //Validamos que el valor password no este vacio
        if (TextUtils.isEmpty(correo)) {
            Toast.makeText(this, "El campo correo electronico esta vacio", Toast.LENGTH_SHORT).show();
            return;
        }

        //Mostramos un ProgresDialog para esperar la rpta del login Firebase
        ProgressDialog dialog = new ProgressDialog(this);
        dialog.setTitle("Registrando");
        dialog.setMessage("Espere por favor...");
        dialog.setCancelable(false);
        dialog.show();

        mAuth.createUserWithEmailAndPassword(correo,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()){
                    dialog.dismiss();
                    Toast.makeText(MainActivity.this, "Se ha registrado correctamente", Toast.LENGTH_SHORT).show();
                }else{
                    dialog.dismiss();
                    Toast.makeText(MainActivity.this, "No se ha podido registrar al usuario", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    private void IniciarSesion() {
        String correo = txt_correo.getText().toString().trim();
        String password = txt_password.getText().toString().trim();

        //Validamos que el valor correo no este vacio
        if (TextUtils.isEmpty(correo)) {
            Toast.makeText(this, "El campo correo electronico esta vacio", Toast.LENGTH_SHORT).show();
            return;
        }

        //Validamos que el valor password no este vacio
        if (TextUtils.isEmpty(correo)) {
            Toast.makeText(this, "El campo correo electronico esta vacio", Toast.LENGTH_SHORT).show();
            return;
        }

        //Mostramos un ProgresDialog para esperar la rpta del login Firebase
        ProgressDialog dialog = new ProgressDialog(this);
        dialog.setTitle("Autentificando");
        dialog.setMessage("Espere por favor...");
        dialog.setCancelable(false);
        dialog.show();

        //Invocamos al metodo de autentificacion del servicio Firebase "Authentification"
        mAuth.signInWithEmailAndPassword(correo, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    dialog.dismiss();
                    Toast.makeText(MainActivity.this, "Has iniciado sesion correctamente", Toast.LENGTH_SHORT).show();
                }else{
                    dialog.dismiss();
                    Toast.makeText(MainActivity.this, "El usuario y/o contraseña son incorrectos", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}